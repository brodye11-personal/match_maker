// GET (admin list/filter), POST (admin add) participants
// TODO: implement participants API
