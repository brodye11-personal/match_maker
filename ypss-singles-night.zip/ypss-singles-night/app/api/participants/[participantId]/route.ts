// PATCH details, DELETE participant
// TODO: implement participant details API
