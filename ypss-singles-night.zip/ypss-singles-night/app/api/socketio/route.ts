// Socket.IO handshake (keeps singleton)
// TODO: implement Socket.IO route
