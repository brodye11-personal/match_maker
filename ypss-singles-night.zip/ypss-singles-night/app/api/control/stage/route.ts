// POST change stage (admin) -> socket push
// TODO: implement stage control API
