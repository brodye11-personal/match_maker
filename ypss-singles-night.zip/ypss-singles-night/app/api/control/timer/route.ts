// POST start/stop/set -> socket push
// TODO: implement timer control API
