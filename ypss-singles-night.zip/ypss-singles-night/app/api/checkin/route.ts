// POST/DELETE check-in
// TODO: implement check-in API
