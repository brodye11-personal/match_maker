// GET/POST prompts
// TODO: implement speed prompts API
