// Create Stripe checkout session
// TODO: implement Stripe checkout
