// GET one, PATCH update, DELETE event
// TODO: implement single event API
