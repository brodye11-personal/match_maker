// POST create, GET list events
// TODO: implement events API
