// POST random (no repeats per member)
// TODO: implement pairings generation API
