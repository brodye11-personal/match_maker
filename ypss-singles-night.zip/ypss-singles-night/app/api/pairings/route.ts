// PATCH manual edits (drag-drop)
// TODO: implement pairings manual edit API
