// Validate promo code
// TODO: implement promo validation
