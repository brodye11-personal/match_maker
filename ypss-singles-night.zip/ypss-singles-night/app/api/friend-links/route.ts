// POST request, PATCH confirm (admin)
// TODO: implement friend links API
