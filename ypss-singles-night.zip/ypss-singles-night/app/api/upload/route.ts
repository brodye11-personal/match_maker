// POST photo upload (cropped)
// TODO: implement upload API
