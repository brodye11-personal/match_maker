// PATCH autosave wizard
// TODO: implement signup autosave API
