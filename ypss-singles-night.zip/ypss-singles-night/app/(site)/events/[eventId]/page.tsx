// Public Event page + countdown + signup CTA
export default function EventPage() {
  return <div>Event details</div>;
}
