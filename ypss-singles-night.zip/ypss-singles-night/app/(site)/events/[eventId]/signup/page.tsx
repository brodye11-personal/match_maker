// Signup wizard (resumable)
export default function SignupPage() {
  return <div>Signup wizard</div>;
}
