// Signup success page
export default function SignupSuccessPage() {
  return <div>Signup successful!</div>;
}
