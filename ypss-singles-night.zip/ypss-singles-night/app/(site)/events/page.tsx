// “Find an event near me” page
export default function EventsPage() {
  return <div>Find an event near me</div>;
}
