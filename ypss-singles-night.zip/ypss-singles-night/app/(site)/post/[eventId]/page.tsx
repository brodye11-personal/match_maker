// Post‑event selections (participant)
export default function PostEventPage() {
  return <div>Post‑event selections</div>;
}
