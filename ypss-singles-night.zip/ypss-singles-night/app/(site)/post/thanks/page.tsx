// Thank you page after post‑event
export default function PostThanksPage() {
  return <div>Thank you!</div>;
}
