// Home page (SEO)
export default function Page() {
  return <div>Home page</div>;
}
