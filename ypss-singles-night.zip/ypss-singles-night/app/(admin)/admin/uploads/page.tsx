// Admin photo browser / download
export default function UploadsPage() {
  return <div>Photo uploads</div>;
}
