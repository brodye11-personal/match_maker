// Manage games + prompts
export default function GamesPage() {
  return <div>Manage games</div>;
}
