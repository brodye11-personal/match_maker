// Manage participants / check‑in / CSV export
export default function ParticipantsPage() {
  return <div>Manage participants</div>;
}
