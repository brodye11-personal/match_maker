// Rounds + prompts + pairings editor
export default function SpeedDatingPage() {
  return <div>Speed dating editor</div>;
}
