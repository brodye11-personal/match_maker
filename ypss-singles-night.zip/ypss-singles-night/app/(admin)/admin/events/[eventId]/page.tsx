// Admin event overview
export default function AdminEventOverview() {
  return <div>Event overview</div>;
}
