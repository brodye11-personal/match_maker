// Night‑of control room (stage/timers)
export default function ControlPage() {
  return <div>Control room</div>;
}
