// Admin list + create events
export default function AdminEventsPage() {
  return <div>Admin events list</div>;
}
