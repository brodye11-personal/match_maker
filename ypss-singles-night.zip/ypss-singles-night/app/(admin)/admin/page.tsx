// Admin dashboard (funnel + alerts)
export default function AdminPage() {
  return <div>Admin dashboard</div>;
}
