// Socket.IO helpers
