// Authentication helpers
