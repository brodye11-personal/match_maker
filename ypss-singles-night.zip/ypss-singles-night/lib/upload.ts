// Photo upload helpers
