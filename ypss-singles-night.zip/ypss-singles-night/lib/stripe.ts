// Stripe integration helpers
