// Promo code helpers
