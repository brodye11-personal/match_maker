// Pairing logic helpers
