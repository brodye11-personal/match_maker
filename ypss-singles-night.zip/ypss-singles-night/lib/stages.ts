// Stage definitions
