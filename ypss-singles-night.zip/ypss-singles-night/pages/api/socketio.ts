// Socket.io server for development
