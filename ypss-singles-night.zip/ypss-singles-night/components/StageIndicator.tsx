export default function StageIndicator() {
  return <div>Stage Indicator</div>;
}
