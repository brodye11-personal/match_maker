export default function PairingsEditor() {
  return <div>Pairings Editor</div>;
}
