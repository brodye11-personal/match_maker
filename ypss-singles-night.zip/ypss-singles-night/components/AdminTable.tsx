export default function AdminTable() {
  return <div>Admin Table</div>;
}
