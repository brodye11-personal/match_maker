export default function RealtimeClient() {
  return <div>Realtime Client</div>;
}
