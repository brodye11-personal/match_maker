export default function PromoCodeInput() {
  return <input type="text" placeholder="Promo code" />;
}
