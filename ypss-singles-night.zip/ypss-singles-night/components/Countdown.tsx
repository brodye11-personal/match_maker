export default function Countdown() {
  return <div>Countdown</div>;
}
