export default function CheckinTable() {
  return <div>Checkin Table</div>;
}
