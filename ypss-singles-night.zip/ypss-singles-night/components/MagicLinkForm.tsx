export default function MagicLinkForm() {
  return <form>Magic Link Form</form>;
}
