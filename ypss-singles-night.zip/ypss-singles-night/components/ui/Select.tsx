export default function Select() {
  return <select />;
}
