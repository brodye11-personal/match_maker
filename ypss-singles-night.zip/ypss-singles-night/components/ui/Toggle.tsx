export default function Toggle() {
  return <input type="checkbox" />;
}
