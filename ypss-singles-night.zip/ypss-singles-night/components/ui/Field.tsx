export default function Field() {
  return <input type="text" />;
}
