export default function SignupWizard() {
  return <div>Signup Wizard</div>;
}
