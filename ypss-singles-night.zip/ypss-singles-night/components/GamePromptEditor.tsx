export default function GamePromptEditor() {
  return <div>Game Prompt Editor</div>;
}
