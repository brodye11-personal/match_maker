export default function PhotoCropper() {
  return <div>Photo Cropper</div>;
}
